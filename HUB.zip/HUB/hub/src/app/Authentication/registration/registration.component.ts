import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.css'
})
export class RegistrationComponent implements OnInit{
  ownerdata!: FormGroup;
    userdata:any;
    emailPattern: RegExp = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    constructor( private fb: FormBuilder){}
    
    ngOnInit(){
      this.ownerdata= this.fb.group({
        email: ['', [Validators.required, Validators.email, Validators.pattern(this.emailPattern)]],      
        first_name:['',Validators.required],
        last_name:['',Validators.required],
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', Validators.required],
        user_type:['petOwner'],
        
      },);
    
    }
    visible:boolean=true;
    changetype:boolean=true;
  
    changetypeConfirm:boolean=true;
    visibleConfirm:boolean=true;
    
    viewPassward(){
      this.visible= !this.visible;
      this.changetype= !this.changetype;
    }
    viewConfirmPassward(){
      this.visibleConfirm= !this.visibleConfirm;
      this.changetypeConfirm= !this.changetypeConfirm;
    }

    confirmRegistration() {
      Swal.fire({
        title: 'Registration Confirmed',
        text: 'Your registration has been successfully confirmed!',
        icon: 'success',
        showConfirmButton: false,  
        timer: 1500,  
        timerProgressBar: true
      }); 
    }
    
    onsubmit() {
      console.log('Form Submitted',this.ownerdata.value);
      // this.ownerservie.data(this.ownerdata.value).subscribe(response => {
      // console.log("Response is:", response);
      //  });

    //    if (!this.ownerdata.get('termsAccepted')?.value) {
    //     alert('You must accept the terms and conditions before submitting!');
    //     return;
    // }
  }
    checkPasswords() {
      const password = this.ownerdata.get('password')?.value;
      const confirmPassword = this.ownerdata.get('confirmPassword')?.value;
  
      if (password !== confirmPassword) {
        // alert('Passwords do not match!');
        
        Swal.fire({
          icon: 'error',
          title: 'Password do not match',
          text: 'Please check your password',
          confirmButtonText: 'OK',
        });
      }
    }
  }


