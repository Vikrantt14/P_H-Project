import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  logindata!: FormGroup;
  visible:boolean=true;
  changetype:boolean=true;
  router: any;
  
  constructor(  private fb: FormBuilder){}

  viewPassward(){
    this.visible= !this.visible;
    this.changetype= !this.changetype;

  }
  
  ngOnInit(): void {
    this.logindata= this.fb.group({
      email: ['', [Validators.required]],
      password: ['']
  },);
}

  onLogin() {
    window.location.href = '/home/petOwner';


   if (!this.logindata.value.email || !this.logindata.value.password) {
    Swal.fire({
      icon: 'warning',
      title: 'Please fill the details',
      text: 'Email and   password are required to log in.',
      showConfirmButton: false,  
        timer: 1500,  
        timerProgressBar: true
    })
      console.error('Form is invalid');
      return;
    }
  
    const { email, password } = this.logindata.value; // Destructure form values
  
    console.log('Form Submitted', this.logindata.value);
  
  //   this.loginservice.login(email, password).subscribe({
  //     next: (response:any) => {
  //       console.log('Response is:', response);
  //       localStorage.setItem('funcdata' ,JSON.stringify(response.data.func_data));
  //       console.log(localStorage.getItem('funcdata'));
  //     if(response && response.status==200 && response.message=="success") {
  //       Swal.fire({
  //         icon: 'success',
  //         title: 'Login Successful',
  //         text: response.message,
  //         showConfirmButton: false,  
  //         timer: 1500,  
  //         timerProgressBar: true
  //       });
  //       window.location.href = '/home/petowner';

  //       // .then(() => {
  //         // Navigate to the dashboard
  //         // window.location.href = '/home/petowner';
  //         // this.router.navigate(['/layout.modules/home']);
  //       // });
  //     } 
  //     else{
  //       Swal.fire({
  //         icon:"error",
  //         title:response.message,
  //         showConfirmButton:false,

  //       });

  //     } 
  //     },
  //     error: (error:any) => {
  //       console.error('Login Error:', error);
  
  //     // Handle user not found (wrong email)
  //     if (error.status === 404) {
  //       // Swal.fire({
  //       //   icon: 'error',
  //       //   title: 'User not found',
  //       //   text: 'The email you entered is not registered. Please check again.',
  //       //   confirmButtonText: 'OK',
  //       // });
  //     } else if (error.status === 200) {
  //       // Handle wrong password
  //       Swal.fire({
  //         icon: 'error',
  //         title: 'Password is wrong',
  //         text: error.message || 'The password you entered is incorrect. Please try again.',
  //         confirmButtonText: 'OK',
  //       });
  //     } else {
  //       // Show a generic error message for other types of errors
  //       Swal.fire({
  //         icon: 'error',
  //         title: 'Login Failed',
  //         text: error.error.message || 'Something went wrong. Please try again later.',
  //         confirmButtonText: 'OK',
  //       });
  //     }
  //   },
  // });
}
}