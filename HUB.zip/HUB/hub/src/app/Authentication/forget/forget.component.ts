import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrl: './forget.component.css'
})
export class ForgetComponent {
  forgetdata!: FormGroup;

  constructor( private fb: FormBuilder){ }

  

    ngOnInit(): void {
      this.forgetdata= this.fb.group({
        email: ['', [Validators.required]] 


    },);
  }
 
    onsubmit(): void {
  
      console.log('Form Submitted',this.forgetdata.value);
      // this.forgetService.forget(this.forgetdata.value).subscribe(response => {
      //   console.log("Response is:", response);
      // });
    }


    onEnter() {
      
      Swal.fire({
        title: 'Check you Email',
      text: 'Link sent on your Email',
      icon: 'success',
      showConfirmButton: false,  // Hide the OK button
      timer: 2000,  
      timerProgressBar: true
      });

    }
}
