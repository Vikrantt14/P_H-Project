import { Component, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrl: './landing.component.css'
})
export class LandingComponent {



@ViewChild('cimages', { static: false }) cimages!: ElementRef;

// Scroll function to move left or right
scrollLeft(): void {
  const scrollAmount = 300; // You can adjust the scroll distance
  if (this.cimages && this.cimages.nativeElement instanceof HTMLElement) {
    this.cimages.nativeElement.scrollBy({
      left: -scrollAmount, // Scroll left by a certain amount
      behavior: 'smooth'   // Smooth scrolling
    });
  }
}

scrollRight(): void {
  const scrollAmount = 300; // You can adjust the scroll distance
  if (this.cimages && this.cimages.nativeElement instanceof HTMLElement) {
    this.cimages.nativeElement.scrollBy({
      left: scrollAmount, // Scroll right by a certain amount
      behavior: 'smooth'  // Smooth scrolling
    });
  }
}


videos = [
  { title: 'first', url: '/assets/videos/first.mp4' },
  { title: 'Second', url: '/assets/videos/second.mp4' },
  { title: 'Third', url: '/assets/videos/third.mp4' },
  { title: 'fourth', url: '/assets/videos/fourth.mp4' },
];
getTopThreeVideos() {
  return this.videos.slice(0, 3);
}
closeCard() {
  const removedVideo = this.videos.shift();
  if (removedVideo) {
    this.videos.push(removedVideo);
  }
}


}