import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './Non-login/header/header.component';
import { LandingComponent } from './Non-login/landing/landing.component';
import { LoginComponent } from './Authentication/login/login.component';
import { ForgetComponent } from './Authentication/forget/forget.component';
import { RegistrationComponent } from './Authentication/registration/registration.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ServiceComponent } from './Non-login/service/service.component';
import { PricingComponent } from './Non-login/pricing/pricing.component';
import { AboutusComponent } from './Non-login/aboutus/aboutus.component';
import { ContactusComponent } from './Non-login/contactus/contactus.component';
import { NoPetComponent } from './after-login/pages/Dashboard/Dash/no-pet/no-pet.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LandingComponent,
    LoginComponent,
    ForgetComponent,
    RegistrationComponent,
    ServiceComponent,
    PricingComponent,
    AboutusComponent,
    ContactusComponent,
    NoPetComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
