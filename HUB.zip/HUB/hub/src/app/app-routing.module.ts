import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingComponent } from './Non-login/landing/landing.component';
import { LoginComponent } from './Authentication/login/login.component';
import { RegistrationComponent } from './Authentication/registration/registration.component';
import { ForgetComponent } from './Authentication/forget/forget.component';
import { ServiceComponent } from './Non-login/service/service.component';
import { ContactusComponent } from './Non-login/contactus/contactus.component';
import { AboutusComponent } from './Non-login/aboutus/aboutus.component';
import { PricingComponent } from './Non-login/pricing/pricing.component';

const routes: Routes = [
  {path:'',component:LandingComponent},
  {path:'login',component:LoginComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'forget',component:ForgetComponent},

{path:'service', component:ServiceComponent},
{path:'pricing', component:PricingComponent},
{path:'aboutUs', component:AboutusComponent},
{path:'contactUs', component:ContactusComponent},

{
  path:'home',
  loadChildren:() => import('./after-login/after-login.module').then(m=>m.AfterLoginModule),
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
