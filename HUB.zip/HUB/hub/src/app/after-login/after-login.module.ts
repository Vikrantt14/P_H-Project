import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AfterLoginRoutingModule } from './after-login-routing.module';
import { AfterLoginComponent } from './after-login.component';
import { PetOwnerComponent } from './pages/authentication/pet-owner/pet-owner.component';
import { PetInfoComponent } from './pages/authentication/pet-info/pet-info.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HistoryComponent } from './pages/Dashboard/Dash/history/history.component';
import { PetsComponent } from './pages/Dashboard/Dash/pets/pets.component';
import { ProfileComponent } from './pages/Dashboard/Dash/profile/profile.component';
import { ServiceComponent } from './pages/Dashboard/Dash/service/service.component';
import { SupportComponent } from './pages/Dashboard/Dash/support/support.component';
import { VetsComponent } from './pages/Dashboard/Dash/vets/vets.component';
import { DashboardComponent } from './pages/Dashboard/dashboard/dashboard.component';
import { MainComponent } from './pages/Instagram/main/main.component';
import { InstaComponent } from './pages/Instagram/insta/insta.component';


@NgModule({
  declarations: [
    AfterLoginComponent,
    PetOwnerComponent,
    PetInfoComponent,
    HistoryComponent,
    PetsComponent,
    ProfileComponent,
    ServiceComponent,
    SupportComponent,
    VetsComponent,
    DashboardComponent,
    MainComponent,
    InstaComponent
  ],
  imports: [
    CommonModule,
    AfterLoginRoutingModule,
    ReactiveFormsModule
  ]
})
export class AfterLoginModule { }
