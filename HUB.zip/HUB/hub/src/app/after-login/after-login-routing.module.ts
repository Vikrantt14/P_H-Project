import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AfterLoginComponent } from './after-login.component';
import { PetInfoComponent } from './pages/authentication/pet-info/pet-info.component';
import { PetOwnerComponent } from './pages/authentication/pet-owner/pet-owner.component';
import { NoPetComponent } from './pages/Dashboard/Dash/no-pet/no-pet.component';
import { PetsComponent } from './pages/Dashboard/Dash/pets/pets.component';
import { InstaComponent } from './pages/Instagram/insta/insta.component';
import { MainComponent } from './pages/Instagram/main/main.component';

const routes: Routes = [
  {path:'', component:AfterLoginComponent,

  children: [ 

    {path:'',redirectTo:'petOwner', pathMatch:'full'},

    {path:'petOwner', component:PetOwnerComponent},
    {path:'petInfo', component:PetInfoComponent},
    {path:'skip', component:NoPetComponent},
    {path:'pets', component:PetsComponent},
    {path:'insta', component:InstaComponent},
    {path:'main', component:MainComponent},


  ]

  
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AfterLoginRoutingModule { }
