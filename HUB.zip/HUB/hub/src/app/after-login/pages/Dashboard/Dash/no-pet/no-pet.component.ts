import { Component } from '@angular/core';

@Component({
  selector: 'app-no-pet',
  templateUrl: './no-pet.component.html',
  styleUrl: './no-pet.component.css'
})
export class NoPetComponent {

}
