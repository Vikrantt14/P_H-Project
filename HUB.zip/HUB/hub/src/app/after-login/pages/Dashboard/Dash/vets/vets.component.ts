import { Component } from '@angular/core';

@Component({
  selector: 'app-vets',
  templateUrl: './vets.component.html',
  styleUrl: './vets.component.css'
})
export class VetsComponent {

}
