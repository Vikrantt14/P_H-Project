import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-pet-owner',
  templateUrl: './pet-owner.component.html',
  styleUrl: './pet-owner.component.css'
})
export class PetOwnerComponent  {
  petownerdata!: FormGroup;
  showmodal:boolean = true;

  // countries:any;

  countryList:any[]=[];
  stateList:any;
  cityList:any;
  selectedState:any;

  selectedCountry:any;
  selectedCity:any;
  profileid: any;
  userid: any;
  
  constructor(private router:Router, private fb: FormBuilder, 
  ){
    // private petownerservice:PetownerService

  }

  fileName: string | null = null;
  selectedFile: File | null = null;



  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.selectedFile = input.files[0];
      this.fileName = this.selectedFile.name;
    }
  }
  confirmOwnerRegistration() {
    Swal.fire({
      title: 'Registration Confirmed',
      text: 'Do you want add',
      icon: 'success',
     
      showConfirmButton: true,  
      showCancelButton: true,
      confirmButtonText: 'Add',
      cancelButtonText: 'Skip'
     }).then((result) => {
      if (result.isConfirmed) {
        
        this.router.navigateByUrl('/home/petInfo');
        // this.router.navigateByUrl('/home/dashboard');
      }
      else {
        this.router.navigateByUrl('/home/skip')
      }
    });
  }
  ngOnInit(){
    console.log('id', this.userid);
    this.ngAfterViewInit();
    console.log('id', this.userid);
    this.petownerdata= this.fb.group({
      mobile_no: ['', Validators.required],
      dob: ['', Validators.required],
      address: ['', Validators.required],
      country: ['', Validators.required],
      state: ['', Validators.required],
      city: ['', Validators.required],
      zipcode: ['', Validators.required],
      file: [''] ,
      user_id:this.userid
    },);
    this.fetchCountryData();

    // this.petownerservice.addressdata(this.petownerdata.value).subscribe({
    //   next:(Response) => {
    //     this.petownerdata= Response;
    //     console.log('response', this.response);
    //   }
    // })

}

fetchCountryData(){
  // this.petownerservice.getCountryData(this.petownerdata.value).subscribe({
  //   next: (response: any) => {
  //     console.log('resp',response);

  //     if (response && response.status==200) {
  //       this.countryList = response.countries; // Correctly assigning the countries array
  //       console.log('country list',this.countryList);
  //     } else {
  //       console.error('Countries data is missing or incorrectly formatted.');
  //     }
  //   },
  //   error: (err:any) => {
  //     console.error('Error fetching country data:', err);
  //   }
  // });
}


// Fetch states based on selected country
onCountryChange(countryId: string) {
  if (!countryId) {
    this.stateList = [];
    this.cityList = [];
    this.petownerdata.patchValue({ state: '', city: '' });
    return;
  }

  // this.petownerservice.getStateData(countryId).subscribe({
  //   next: (response: any) => {
  //     console.log('resp',response);
  //     if (response && response.status == 200) {
  //       this.stateList = response.states; // Populate the states array
  //       console.log('state list', this.stateList);
  //     } else {
  //       console.error('States data is missing or incorrectly formatted.');
  //       this.stateList = [];
  //     }
  //   },
  //   error: (err:any) => {
  //     console.error('Error fetching state data:', err);
  //     this.stateList = [];
  //   }
  // });
}

// Fetch cities based on selected state
onStateChange(stateId: string) {
  if (!stateId) {
    this.cityList = [];
    this.petownerdata.patchValue({ city: '' });
    return;
  }

  // this.petownerservice.getCityData(stateId).subscribe({
  //   next: (response: any) => {
  //     console.log('resp',response);
  //     if (response && response.status == 200) {
  //       this.cityList = response.cities; // Populate the cities array
  //       console.log('city list', this.cityList);
  //     } else {
  //       console.error('Cities data is missing or incorrectly formatted.');
  //       this.cityList = [];
  //     }
  //   },
  //   error: (err:any) => {
  //     console.error('Error fetching city data:', err);
  //     this.cityList = [];
  //   }
  // });
}

  onSubmit(){
    console.log('Form Submitted',this. petownerdata.value);
    // this.petownerservice.ownerdata(this.petownerdata.value).subscribe(response => {
    //   console.log("Response is:", response);
    //  });
    this.closemodel();

  }

 openmodal(){
   this.showmodal=true;
  }

  closemodel(){
    this.showmodal=false;
  }

  ngAfterViewInit() {
  let funcdata = localStorage.getItem('funcdata');
  if(funcdata){
   let user = JSON.parse(funcdata);
   this.userid = user.id;
   console.log(this.userid);
  }

  }
}
