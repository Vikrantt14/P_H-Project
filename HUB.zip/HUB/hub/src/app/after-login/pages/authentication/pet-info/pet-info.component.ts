import { Component } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pet-info',
  templateUrl: './pet-info.component.html',
  styleUrl: './pet-info.component.css'
})
export class PetInfoComponent  {

  petmoreData!:FormGroup;
  speciesList: any;
  breedList: any;
  filteredBreeds: any;
  selectedSpecies: any;



  fileName: string | null = null;
  selectedFile: File | null = null;
  router: any;

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.selectedFile = input.files[0];
      this.fileName = this.selectedFile.name;
    }
  }

  constructor( private fb: FormBuilder, private routerr:Router) { }
  data: any;



  ngOnInit(){
    this.petmoreData= this.fb.group({
    name: [''],
     dob: [''],
     gender: [''],
    file: [''],
    species:[''],
    breed:[''],
  },);

    // this.petinfoservice.data(this.petmoreData.value).subscribe({
    //   next: (response:any) => {
    //     this.data = response;
    //     this.speciesList = response.data.speciesData;
    //     this.breedList = response.data.breedsData;

    //     console.log('Species List:', this.speciesList);
    //     console.log('Breed List:', this.breedList);

    //   },
    //   error: (err) => {
    //     console.error('Error fetching data:', err); 
    //   }
    // });
  }


  onSubmit(){
    console.log('Form Submitted',this. petmoreData.value);
      // this.petinfoservice.moredata(this.petmoreData.value).subscribe(response => {
      //   console.log("Response is:", response);
      //  });
      this.routerr.navigateByUrl('/home/pets');

  }

  onSpeciesChange(species_id: any): void {
    console.log('Sleected :', this.selectedSpecies);
    this.filteredBreeds = this.breedList.filter((breed: { species_id: any; }) => (breed.species_id == this.selectedSpecies));

    console.log('Filtered Breeds:', this.filteredBreeds);
  }

  // confirmPetRegistration() {
  //   Swal.fire({
  //     title: 'Registration Confirmed',
  //     text: 'Your registration has been successfully confirmed!',
  //     icon: 'success',
     
  //     showConfirmButton: true,  // Hide the OK button
  //     showCancelButton: true,
  //     confirmButtonText: 'Add',
  //     cancelButtonText: 'Skip'
  //    }).then((result) => {
  //     if (result.isConfirmed) {
        
  //       this.router.navigateByUrl('/home/dashboard');
  //     }
  //   });
  // }








}
