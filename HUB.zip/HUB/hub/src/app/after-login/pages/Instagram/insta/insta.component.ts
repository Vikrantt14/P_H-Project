import { Component } from '@angular/core';

@Component({
  selector: 'app-insta',
  templateUrl: './insta.component.html',
  styleUrl: './insta.component.css'
})
export class InstaComponent {

}
